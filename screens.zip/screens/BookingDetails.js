// BookingDetails.js
import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, ActivityIndicator, SafeAreaView, TouchableOpacity } from "react-native";
import api from "../api/client";

export default function BookingDetails({ route, navigation }) {
  const { bookingId } = route.params;
  const [booking, setBooking] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchBooking = async () => {
    try {
      const { data } = await api.get(`/bookings/${bookingId}`);
      setBooking(data);
    } catch (err) {
      console.error("❌ Booking fetch error:", err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchBooking(); }, []);

  if (loading) {
    return <View style={styles.centered}><ActivityIndicator size="large" /><Text>Loading booking…</Text></View>;
  }

  if (!booking) {
    return <View style={styles.centered}><Text>Booking not found.</Text></View>;
  }

  return (
    <SafeAreaView style={styles.safe}>
      <Text style={styles.title}>Booking Details</Text>
      <View style={styles.card}>
        <Text style={styles.label}>Mechanic:</Text>
        <Text style={styles.value}>{booking.mechanic?.name || "Unknown"}</Text>

        <Text style={styles.label}>Service:</Text>
        <Text style={styles.value}>{booking.serviceType}</Text>

        <Text style={styles.label}>Problem:</Text>
        <Text style={styles.value}>{booking.problemDescription || "-"}</Text>

        <Text style={styles.label}>Scheduled:</Text>
        <Text style={styles.value}>{booking.scheduledTime ? new Date(booking.scheduledTime).toLocaleString() : "ASAP"}</Text>

        <Text style={styles.label}>Status:</Text>
        <Text style={styles.value}>{booking.status?.toUpperCase()}</Text>

        <Text style={styles.label}>Payment:</Text>
        <Text style={styles.value}>{booking.payment?.mode} - {booking.payment?.status}</Text>
      </View>

      <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate("Bookings")}>
        <Text style={styles.btnText}>Back to My Bookings</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#fff", padding: 20 },
  centered: { flex: 1, justifyContent: "center", alignItems: "center" },
  title: { fontSize: 22, fontWeight: "700", marginBottom: 20 },
  card: {
    backgroundColor: "#fafafa", padding: 16, borderRadius: 12,
    marginBottom: 20, borderWidth: 1, borderColor: "#eee",
  },
  label: { fontSize: 14, fontWeight: "600", color: "#555", marginTop: 8 },
  value: { fontSize: 16, fontWeight: "700", color: "#111" },
  btn: {
    backgroundColor: "#C98A52", padding: 14, borderRadius: 12,
    alignItems: "center",
  },
  btnText: { color: "#fff", fontWeight: "700", fontSize: 16 },
});
