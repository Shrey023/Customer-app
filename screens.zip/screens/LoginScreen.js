import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import API from "../api/client"; // axios instance for backend

export default function LoginScreen({ navigation }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      return Alert.alert("Error", "Please fill in all fields");
    }

    try {
      setLoading(true);
      console.log("📤 Sending login request:", { email, password });

      const res = await API.post("/customers/login", { email, password });

      console.log("✅ Login success:", res.data);

      // ✅ Save customerId and token in AsyncStorage
      await AsyncStorage.setItem("customerId", res.data.customer._id);
      if (res.data.token) {
        await AsyncStorage.setItem("token", res.data.token);
      }

      
      Alert.alert("Success", "Login successful!");
      navigation.replace("Tabs"); // replace so user can't go back to login

    } catch (err) {
      console.error("❌ Login error:", err);
      Alert.alert(
        "Error",
        err.response?.data?.message || "Login failed. Try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Customer Login</Text>

      {/* Email Input */}
      <TextInput
        style={styles.input}
        placeholder="Enter Email"
        keyboardType="email-address"
        autoCapitalize="none"
        value={email}
        onChangeText={setEmail}
      />

      {/* Password Input */}
      <TextInput
        style={styles.input}
        placeholder="Enter Password"
        secureTextEntry
        value={password}
        onChangeText={setPassword}
      />

      {/* Login Button */}
      <TouchableOpacity
        style={styles.button}
        onPress={handleLogin}
        disabled={loading}
      >
        <Text style={styles.buttonText}>
          {loading ? "Logging in..." : "Login"}
        </Text>
      </TouchableOpacity>

      <Text style={styles.orText}>OR</Text>

      {/* Google Login */}
      <TouchableOpacity style={[styles.button, styles.googleButton]}>
        <Text style={styles.buttonText}>Login with Google</Text>
      </TouchableOpacity>

      {/* OTP Login */}
      <TouchableOpacity
        style={[styles.button, styles.otpButton]}
        onPress={() => navigation.navigate("OTP")}
      >
        <Text style={styles.buttonText}>Login with OTP</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 30,
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
  },
  button: {
    width: "100%",
    backgroundColor: "#007BFF",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    alignItems: "center",
  },
  buttonText: {
    color: "#fff",
    fontWeight: "bold",
  },
  googleButton: {
    backgroundColor: "#DB4437",
  },
  otpButton: {
    backgroundColor: "#28A745",
  },
  orText: {
    marginVertical: 10,
    fontSize: 16,
    fontWeight: "500",
  },
});
