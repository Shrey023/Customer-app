import React, { useEffect, useState } from "react";
import { View, Text, StyleSheet, TouchableOpacity, Image, ScrollView } from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";

export default function ProfileScreen({ navigation }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const customerData = await AsyncStorage.getItem("customerData"); // store this after login
        if (customerData) {
          setUser(JSON.parse(customerData));
        }
      } catch (err) {
        console.error("Error fetching user:", err);
      }
    };
    fetchUser();
  }, []);

const handleLogout = async () => {
  await AsyncStorage.clear();
  navigation.reset({
    index: 0,
    routes: [{ name: "Login" }], // go back to login in the stack
  });
};

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ padding: 20 }}>
      {/* Header */}
      <View style={styles.header}>
        <Image
          source={{ uri: "https://i.ibb.co/0Jmshvb/avatar.png" }}
          style={styles.avatar}
        />
        <Text style={styles.name}>{user?.name || "Guest User"}</Text>
        <Text style={styles.email}>{user?.email || "Not logged in"}</Text>
      </View>

      {/* Info cards */}
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Personal Info</Text>
        <Text style={styles.cardText}>📞 {user?.phone || "Not provided"}</Text>
        <Text style={styles.cardText}>📍 {user?.address || "No address saved"}</Text>
      </View>

      <View style={styles.card}>
        <Text style={styles.cardTitle}>Preferences</Text>
        <Text style={styles.cardText}>Payment Method: {user?.paymentMode || "Cash"}</Text>
        <Text style={styles.cardText}>Default Vehicle: {user?.vehicle || "Not set"}</Text>
      </View>

      {/* Buttons */}
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate("Bookings")}>
        <Text style={styles.buttonText}>📖 View My Bookings</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, styles.logoutButton]} onPress={handleLogout}>
        <Text style={styles.buttonText}>🚪 Logout</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#fff" },
  header: { alignItems: "center", marginBottom: 20 },
  avatar: { width: 100, height: 100, borderRadius: 50, marginBottom: 12 },
  name: { fontSize: 22, fontWeight: "800", color: "#111" },
  email: { fontSize: 14, color: "#666", marginTop: 4 },

  card: {
    backgroundColor: "#fff",
    borderRadius: 14,
    padding: 16,
    marginBottom: 14,
    shadowColor: "#000",
    shadowOpacity: 0.06,
    shadowRadius: 6,
    shadowOffset: { width: 0, height: 3 },
    elevation: 2,
  },
  cardTitle: { fontSize: 16, fontWeight: "700", marginBottom: 8, color: "#333" },
  cardText: { fontSize: 14, color: "#555", marginBottom: 4 },

  button: {
    backgroundColor: "#C98A52",
    paddingVertical: 14,
    borderRadius: 12,
    alignItems: "center",
    marginBottom: 12,
  },
  buttonText: { color: "#fff", fontWeight: "700", fontSize: 16 },
  logoutButton: { backgroundColor: "#E63946" },
});
