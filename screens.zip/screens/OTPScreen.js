import React, { useRef, useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from "react-native";
import { FirebaseRecaptchaVerifierModal } from "expo-firebase-recaptcha";
import {
  getAuth,
  signInWithPhoneNumber,
  PhoneAuthProvider,
  signInWithCredential,
} from "firebase/auth";
import { app, firebaseConfig } from "../config/firebase";
import API from "../api/client"; // axios instance pointing to your backend

const auth = getAuth(app);

export default function OTPScreen({ navigation }) {
  const recaptchaVerifier = useRef(null);

  const [phone, setPhone] = useState("");
  const [verificationId, setVerificationId] = useState(null);
  const [otp, setOtp] = useState("");
  const [loading, setLoading] = useState(false);

  // Send OTP
  const sendOtp = async () => {
    try {
      const digits = phone.replace(/\D/g, "");
      if (digits.length < 10) {
        return Alert.alert("Error", "Enter a valid phone number");
      }

      const e164 = phone.startsWith("+") ? phone : `+91${digits.slice(-10)}`;
      console.log("📤 Sending OTP to:", e164);

      const confirmation = await signInWithPhoneNumber(
        auth,
        e164,
        recaptchaVerifier.current
      );

      setVerificationId(confirmation.verificationId);
      Alert.alert("Success", "OTP sent to " + e164);
    } catch (err) {
      console.log("❌ Send OTP error:", err);
      Alert.alert("Error", err.message);
    }
  };

  // Verify OTP
  const verifyOtp = async () => {
    if (!verificationId)
      return Alert.alert("Error", "Please request OTP first");
    if (otp.length < 6) return Alert.alert("Error", "Enter 6-digit OTP");

    try {
      setLoading(true);
      console.log("🔑 Verifying OTP...");

      const credential = PhoneAuthProvider.credential(verificationId, otp);
      await signInWithCredential(auth, credential);

      const user = auth.currentUser;
      if (!user) throw new Error("No Firebase user after OTP verification");

      const idToken = await user.getIdToken();
      console.log("🔍 [DEBUG] ID Token:", idToken);

      console.log("📤 Sending verify request to backend...");
      const res = await API.post("/customers/verify-otp", { idToken });
      console.log("✅ Backend response:", res.data);

      const { token, _id, isNew } = res.data;
      Alert.alert("Success", "OTP verified successfully!");
      setLoading(false);

      if (isNew) {
        // First-time user → go to RegistrationDetails
        navigation.replace("RegistrationDetails", {
          token,
          customerId: _id,
        });
      } else {
        // Existing user → go to Home
        navigation.replace("Home", { token, customerId: _id });
      }
    } catch (err) {
      console.log("❌ [DEBUG] Verify OTP error:", err);
      setLoading(false);
      Alert.alert("Error", err.message || "OTP verification failed");
    }
  };

  return (
    <View style={styles.container}>
      <FirebaseRecaptchaVerifierModal
  ref={recaptchaVerifier}
  firebaseConfig={firebaseConfig}
  style={{
    position: 'absolute',
    bottom: 5,
    right: 5,
    width: 1,
    height: 1,
    opacity: 0.01,
  }}
/>


      <Text style={styles.title}>Login with OTP</Text>

      {/* Phone Number Input */}
      <TextInput
        style={styles.input}
        placeholder="Enter Mobile Number"
        keyboardType="phone-pad"
        value={phone}
        onChangeText={setPhone}
      />

      <TouchableOpacity style={styles.button} onPress={sendOtp}>
        <Text style={styles.buttonText}>Send OTP</Text>
      </TouchableOpacity>

      {/* OTP Input */}
      {verificationId && (
        <>
          <TextInput
            style={styles.input}
            placeholder="Enter OTP"
            keyboardType="number-pad"
            maxLength={6}
            value={otp}
            onChangeText={setOtp}
          />

          <TouchableOpacity
            style={styles.button}
            onPress={verifyOtp}
            disabled={loading}
          >
            <Text style={styles.buttonText}>
              {loading ? "Verifying..." : "Verify OTP"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.resendButton} onPress={sendOtp}>
            <Text style={styles.resendText}>Resend OTP</Text>
          </TouchableOpacity>
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    justifyContent: "center",
    backgroundColor: "#fff",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  input: {
    width: "100%",
    borderWidth: 1,
    borderColor: "#ccc",
    borderRadius: 8,
    padding: 10,
    marginBottom: 15,
  },
  button: {
    backgroundColor: "#28A745",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 10,
  },
  buttonText: { color: "#fff", fontWeight: "bold" },
  resendButton: { marginTop: 10, alignItems: "center" },
  resendText: { color: "#007BFF", fontWeight: "600" },
});
